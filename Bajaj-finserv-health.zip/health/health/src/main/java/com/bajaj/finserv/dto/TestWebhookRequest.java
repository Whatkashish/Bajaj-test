package com.bajaj.finserv.dto;


import com.fasterxml.jackson.annotation.JsonProperty;


public class TestWebhookRequest {
    @JsonProperty("finalQuery")
    private String finalQuery;

    public String getFinalQuery() {
        return finalQuery;
    }

    public void setFinalQuery(String finalQuery) {
        this.finalQuery = finalQuery;
    }
}
