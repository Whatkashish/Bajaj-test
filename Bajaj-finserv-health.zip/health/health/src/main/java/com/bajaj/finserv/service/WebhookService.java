package com.bajaj.finserv.service;

import com.bajaj.finserv.dto.TestWebhookRequest;
import com.bajaj.finserv.response.WebhookResponse;
import com.bajaj.finserv.dto.WebhookRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class WebhookService {

    @Autowired
    private RestTemplate restTemplate;

    private static final String GENERATE_WEBHOOK_URL = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";
    private static final String TEST_WEBHOOK_URL = "https://bfhldevapigw.healthrx.co.in/hiring/testWebhook/JAVA";

    public WebhookResponse generateWebhook() {
        WebhookRequest request = new WebhookRequest();
        request.setName("Kashish Pawar");
        request.setRegNo("0126CS221100");
        request.setEmail("kashishpwr11@gmail.com");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<WebhookRequest> entity = new HttpEntity<>(request, headers);

        ResponseEntity<WebhookResponse> response = restTemplate.postForEntity(
                GENERATE_WEBHOOK_URL, entity, WebhookResponse.class
        );

        return response.getBody();
    }

    public WebhookResponse testWebhook(String accessToken) {
        TestWebhookRequest request = new TestWebhookRequest();
        request.setFinalQuery("SELECT " +
                "    E1.EMP_ID," +
                "    E1.FIRST_NAME," +
                "    E1.LAST_NAME," +
                "    D.DEPARTMENT_NAME," +
                "    COUNT(E2.EMP_ID) AS YOUNGER_EMPLOYEES_COUNT " +
                "FROM " +
                "    EMPLOYEE E1 " +
                "JOIN " +
                "    DEPARTMENT D ON E1.DEPARTMENT = D.DEPARTMENT_ID " +
                "LEFT JOIN " +
                "    EMPLOYEE E2 " +
                "    ON E1.DEPARTMENT = E2.DEPARTMENT " +
                "    AND E1.DOB < E2.DOB  " +
                "GROUP BY " +
                "    E1.EMP_ID, " +
                "    E1.FIRST_NAME," +
                "    E1.LAST_NAME, " +
                "    D.DEPARTMENT_NAME " +
                "ORDER BY " +
                "    E1.EMP_ID DESC");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", accessToken);
        HttpEntity<TestWebhookRequest> entity = new HttpEntity<>(request, headers);

        ResponseEntity<WebhookResponse> response = restTemplate.postForEntity(
                TEST_WEBHOOK_URL, entity, WebhookResponse.class);

        return response.getBody();
    }
}
